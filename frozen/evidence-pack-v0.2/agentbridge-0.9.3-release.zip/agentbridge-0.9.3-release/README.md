# agentbridge

**Verifiable delivery between autonomous agents.** A small, dependency-free Python library + CLI
that lets two agents (or two processes acting for them) exchange work over a shared filesystem,
and later prove to a third party what was requested, what was delivered, and whether either side
changed its story afterwards.

No network. No consensus. No tokens. Just a hash-chained ledger, a content-addressed artifact
store, and an anchor the human holds outside the machine.

```console
$ agentbridge init --actor planner
bridge ready
$ agentbridge send --actor planner --to worker --intent review \
    --body "review this module" --attach ./build.py
$ agentbridge requests --actor worker
[20261020T161249-planner-c20c4f...] planner -> worker  intent=review  ...  [verified]
   | review this module
$ agentbridge deliver --actor worker --to planner --in-reply-to <id> \
    --body "two findings" --attach ./findings.md
$ agentbridge verify
ledger: 4 entries, chain OK
envelopes: 2 checked, 0 failing
artifacts: 2 verified in store, 0 failing, 0 original path(s) drifted (info)
```

## The problem

When two agents collaborate, each side has to trust the other's *claims*: that a file existed,
that it was not modified after review, that a promise to fix something was not quietly deleted
from the record. Human teams solve this with third parties (contracts, notaries, auditors).
Agents have no such institutions — and if both agents run with the same privileges, neither can
be an authority over the other.

`agentbridge` does not try to be that authority. It gives the two agents a shared, tamper-evident
record, and it gives the *human* an anchor they can hold outside the system. That is a smaller
promise, and it is one that can actually be kept.

## What it proves, and what it doesn't

| It proves | It does not prove |
|---|---|
| This artifact existed, with this digest, when the delivery was recorded | Without keys, who produced it — `--actor` is only a claim |
| With `keygen` + `register`: which key signed each entry and envelope | That the key holder is the human you think it is |
| The envelope (the conclusion actually reported) matches what was recorded, even after archival | That the agent was honest about the outside world |
| A tail entry cannot be silently truncated **and healed** by a later write | That a coordinated rewrite of `ledger.jsonl` + `wire/head.json` didn't happen |
| Changes to middle entries are detectable | That the machine was not compromised by the same OS user |
| Dangling references and commitments are rejected | Anything at all about intent, meaning, or adjudication |

The last row of the right column is the honest boundary: **a same-user rewrite of two files is
invisible without an external anchor.** That is why `agentbridge anchor` exists — copy the digest
somewhere off the filesystem (a ticket, a git remote, another machine). With it:

```console
$ agentbridge anchor
{"seq": 20, "digest": "460b57c7…", "verify_with": "--expect-head 20:460b57c7…"}
$ agentbridge verify --expect-head 20:460b57c7…
```

## Install

```console
pip install -e .          # from a checkout; no runtime dependencies
```

Python 3.9+. The package has zero runtime dependencies. Global flags: `--root DIR`, `--key KEYFILE`
(the key file also sets the acting identity), and `--remote URL` (use the sequencer instead of the
local filesystem).

## Design in thirty seconds

- **Envelope** — one JSON file per message, in `wire/outbox/` (requests) or `wire/inbox/` (deliveries).
  Carries `from`/`to`/`intent`/`in_reply_to`/`body` and a list of artifacts with their sha256.
- **Artifact store** — every attachment is copied to `wire/artifacts/<sha256>`. Verification runs
  against that copy, not the original path, so editing or deleting the original cannot erase the
  evidence (it only shows up as `drifted`).
- **Ledger** — `ledger.jsonl`, append-only, one entry per send/deliver/consume/commit/repair, each
  entry carrying `prev` and its own `digest` (sha256 over a canonical JSON encoding).
- **Head anchor** — `wire/head.json` records the current tip. Appends are *fail-closed*: if the
  ledger tip and the anchor disagree, nothing is written, so a deleted tail entry cannot be
  "healed" by the next ordinary operation.
- **External anchor** — `anchor` prints the tip so a human can hold it off-machine; `verify
  --expect-head SEQ:DIGEST` checks against it. This is the only defence against a coordinated
  rewrite, and it is deliberately a human responsibility.

See [docs/protocol.md](docs/protocol.md) and [docs/threat-model.md](docs/threat-model.md).

## CLI

| Command | Purpose |
|---|---|
| `keygen` | create an Ed25519 key pair for an actor (`--out DIR`, `--force`) |
| `register` | register this key as an actor in the ledger (needs `--key`) |
| `actors [--json]` | list the trust set: actor, key fingerprint, registration seq/time |
| `init` | create or check a bridge (`--recover-empty`, `--rebind-marker` for explicit recovery) |
| `send` | send a request, optionally with attachments |
| `deliver` | deliver a result in reply to a recorded request |
| `requests` | read pending requests (outbox) addressed to an agent |
| `poll [--consume]` | read the inbox; unverified envelopes are refused, exit code 2 |
| `serve` | run an HTTP sequencer over a bridge directory (`--host`, `--port`) |
| `anchor-service` | run a hosted anchor notary (`--dir`, `--host`, `--port`; needs `--key`) |
| `anchor-submit` | submit the current tip to an anchor service (`--url`) |
| `anchor-verify` | verify a receipt against this ledger (`--receipt`) |
| `mcp [--actor]` | run an MCP stdio server exposing the bridge as tools |
| `verify [--expect-head] [--expect-anchor]` | check chain, envelopes, artifact store, anchors; reports `local_only` vs `anchored` |
| `anchor` | print the head digest to hold off-filesystem |
| `commit` | record a commitment ("I will fix X", "done when Y") |
| `ledger` / `show` / `doctor` | inspect |
| `repair --accept-head-loss` | re-anchor after a failed head write, recording the abandoned head |

## Hosted anchors (the paid layer)

A receipt from an anchor service is a portable, signed proof that a ledger tip existed at a point
in time — on a machine you do not control. It is the only defence against a coordinated rewrite.

```console
$ agentbridge --root ./shared --key ./keys/planner.key anchor-submit --url https://anchor.example
$ agentbridge --root ./shared verify --expect-anchor ./shared/wire/anchors/anchor-12-….json
```

The service sees only `(bridge_id, seq, digest)`, submissions are client-signed, receipts are
service-signed, and the service log is an append-only chain that refuses equivocation. See
[docs/anchors.md](docs/anchors.md).

## Network transport (sequencer)

Agents on different machines can share one ledger through a small HTTP sequencer. The server holds
**no actor keys**: it verifies and orders client-signed entries, so a compromised server can
reorder or withhold, but cannot forge authorship.

```console
$ agentbridge --root ./shared serve --port 8765
$ agentbridge --remote http://127.0.0.1:8765 --key ./keys/worker.key send --to planner --body "review"
```

Every request is Ed25519-signed (timestamp + nonce, replay-protected), and the ledger entry itself
is built and signed client-side. The MCP server works remotely with no extra code path:
`agentbridge --remote URL --key K mcp`. See [docs/transport.md](docs/transport.md).

## Identity (optional signing)

By default `--actor` is a string. With keys, it becomes a signature:

```console
$ agentbridge keygen --actor planner --out ./keys
{"actor": "planner", "pub_hex": "0ec96d15…", "keyfile": "/abs/keys/planner.key"}
$ agentbridge --root ./shared --key ./keys/planner.key register
$ agentbridge --root ./shared --key ./keys/planner.key send --to worker --body "review" --attach build.py
$ agentbridge --root ./shared verify
ledger: 3 entries, chain OK          # every entry and envelope checked against the actor registry
```

- Ed25519 per RFC 8032, implemented in pure Python so the package keeps zero dependencies.
  Cross-checked byte-for-byte against OpenSSL via the `cryptography` package
  (`tests/crosscheck_signing.py`).
- Key files are secrets. Keep them **outside** the bridge directory — the point is that a
  compromise of the shared directory does not yield signing keys.
- The first `register` for an actor wins. A second key for the same actor is reported as a
  conflict, not treated as a rotation (rotation would need a signed succession chain; not yet).
- History recorded before the first registration is exempt, so keys can be added to an existing
  bridge. Bridges that never use keys keep verifying exactly as before.

## MCP server

`agentbridge --root ./shared mcp --actor worker` speaks the Model Context Protocol over stdio, so
any MCP-capable agent can use the bridge as tools (`send_request`, `deliver_result`,
`list_requests`, `poll_inbox`, `verify_bridge`, `get_anchor`, …) with no Python integration.
See [docs/mcp.md](docs/mcp.md) for the client config and the tool table.

## Python

```python
from agentbridge import Bridge, Refused

a = Bridge("./shared")
a.init(actor="planner")
req = a.send(actor="planner", to="worker", intent="review",
             body="review this", attach=["build.py"])

b = Bridge("./shared")
b.deliver(actor="worker", to="planner", in_reply_to=req["id"],
          body="two findings", attach=["findings.md"])

report = a.verify()
assert report.ok, report.problems
```

Errors are typed: `NotInitialised`, `BrokenLedger`, `CorruptLedger`, `Refused`, `NotFound`,
`BadArtifact`. Each has a stable `code` for programmatic handling.

## Testing

```console
PYTHONPATH=src python3 tests/run_tests.py
PYTHONPATH=src python3 tests/run_identity_tests.py   # 10 identity cases
PYTHONPATH=src python3 tests/run_mcp_tests.py    # 12 integration tests against the real server
PYTHONPATH=src python3 tests/run_transport_tests.py  # 11 HTTP transport tests (real sequencer)
PYTHONPATH=src python3 tests/run_anchor_tests.py     # 10 hosted-anchor tests (real service)

# optional: cross-check the hand-rolled MCP server against the official MCP SDK (Python 3.10+)
python3.11 -m venv .venv && .venv/bin/pip install mcp
PYTHONPATH=src .venv/bin/python tests/crosscheck_official_sdk.py
.venv/bin/pip install cryptography
PYTHONPATH=src .venv/bin/python tests/crosscheck_signing.py
```

30 adversarial regression cases plus **11 identity cases** (including RFC 8032 §7.1 test vector 1),
dependency-free. Most are literal reproductions of attacks that
defeated earlier versions of this design — truncating a tail entry, deleting the init marker,
forging an envelope so `poll --consume` launders it into the ledger, calling `commit` before
`init`, and so on. If you change the storage format, these are the tests that matter.

## Provenance

The core was extracted from a working prototype used to run five rounds of adversarial review
between two different agent harnesses on one machine (DSH ↔ Hermes). The reviewer's job was to
break it, not to approve it; every round found real defects, including in the fixes for the
previous round. The findings are kept in the prototype directory as evidence of what
"tamper-evident" actually costs to get right.

The most useful thing that came out of it: **verification is cheap to add and easy to over-claim.
Accountability is neither.** This library is only the first half.

## Status

`0.9.3`, local-first alpha. Known gaps, stated rather than hidden:

- Same-user filesystem threat model. Signatures prove key possession, not key custody: a key file
  on the shared disk is readable by the same user. Keep keys elsewhere.
- No rotation/revocation protocol; registry is trust-on-first-use.
- An MCP stdio server on top of the filesystem transport, cross-checked against the official
  MCP Python SDK 2.3.0 (`tests/crosscheck_official_sdk.py`), and used for a real task by a
  different agent harness on the same machine. A networked transport
  (HTTP or an MCP server exposed over SSE/streamable HTTP) would need a real identity layer first.
- `head.json` is a plain JSON file; protecting it requires the external anchor.
- No multi-writer coordination beyond `flock` on a local filesystem.
- Naming: `agentbridge` is a working name.

## License

MIT.
